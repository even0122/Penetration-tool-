
Just include "ThemidaSDK.h" in your source code.

The rest of the files are used by ThemidaSDK.h if required.


