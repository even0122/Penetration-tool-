
1) include "SecureEngineMacros.h" in your source code.

2) Read "How to add ASM files in your Solution.pdf"

3) In Visual Studio, in your Solution Explorer, just add the file "SecureEngineMacros.asm"


