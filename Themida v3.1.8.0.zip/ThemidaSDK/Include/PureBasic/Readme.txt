The ".pbi" files use PureBasic Macros to insert the protection macros.

The ".pb" files use PureBasic Functions to insert the protection macros.

We recommend that you include the ".pbi" files instead of the ".pb" files. If your protection macros, 
via the ".pbi" file, are not recognized you can try with the ".pb" file instead.

 