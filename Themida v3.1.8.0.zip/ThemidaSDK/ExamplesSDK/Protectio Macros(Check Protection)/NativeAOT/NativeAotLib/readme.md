To build this project on Windows execute in the project's folder:

`dotnet publish -c Release -r win-x64`

resulting AOT native DLL will be in \NativeAotLib\bin\Release\net8.0\win-x64\publish\ folder
there also will be a corresponding .MAP file: NativeAotLib.map